# decision_trace.md
This file is emitted by the Resonance Engine compiler during compilation cycles.

Required fields per cycle:
- cycle_index
- role_prompt_hashes
- constraint_health_score
- submetric_scores
- dissent_score
- action_taken

(Template — populated by the code bot.)
