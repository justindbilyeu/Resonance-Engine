import os
import json
import subprocess
import sys
from pathlib import Path

def test_quick_run_emits_outputs(tmp_path: Path):
    """
    Golden-path smoke test:
    - runs the experiment in --quick mode
    - asserts expected artifacts exist
    - asserts null evaluation JSON is well-formed
    """
    bundle_root = Path(__file__).resolve().parents[1]
    runner = bundle_root / "src" / "experiment_0001_rfo_ringing_wedge.py"
    out_dir = tmp_path / "outputs"

    # Run quick sweep
    subprocess.check_call([sys.executable, str(runner), "--quick", "--out", str(out_dir), "--no-negative-control"])

    # Expected artifacts
    expected = [
        out_dir / "parameters_used.json",
        out_dir / "seed_manifest.json",
        out_dir / "grid.csv",
        out_dir / "wedge_report.md",
        out_dir / "null_evaluation.json",
        out_dir / "points",
    ]
    for p in expected:
        assert p.exists(), f"Missing artifact: {p}"

    # Null evaluation schema
    with open(out_dir / "null_evaluation.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    assert "rejected" in data
    assert "nulls" in data
    assert "summary" in data

def test_nulls_contains_numeric_thresholds():
    """
    Compilation hard-gate proxy:
    ensure NULLS.md includes >=2 numeric thresholds.
    """
    bundle_root = Path(__file__).resolve().parents[1]
    nulls_path = bundle_root / "NULLS.md"
    txt = nulls_path.read_text(encoding="utf-8")

    # Count numeric literals that appear in rejection clauses (crude but effective)
    import re
    nums = re.findall(r"\b\d+(?:\.\d+)?\b", txt)
    assert len(nums) >= 2, "NULLS.md must contain >=2 numeric thresholds"
