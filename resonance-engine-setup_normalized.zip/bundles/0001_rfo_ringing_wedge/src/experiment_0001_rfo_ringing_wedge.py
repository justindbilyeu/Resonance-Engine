#!/usr/bin/env python3
"""
experiment_0001_rfo_ringing_wedge.py

Resonance Engine — compiled experiment runner scaffold for Bundle #0001.
This is a runnable baseline implementation (numpy-only) intended for:
- Deterministic parameter sweeps (with --quick mode for smoke tests)
- Producing bundle-specified artifacts (grid.csv, wedge_report.md, parameters_used.json, seed_manifest.json)
- Evaluating NULLS.md criteria and writing a null evaluation report

Performance note:
The full prereg sweep (81x61 grid, 3 reps, 200k steps) is computationally heavy.
This scaffold prioritizes clarity + determinism. Optimize later (Numba/JAX, vectorization,
GPU, parallelism, sparse/low-rank approximations) without changing prereg thresholds.
"""

from __future__ import annotations

import argparse
import json
import math
import os
from dataclasses import dataclass, asdict
from typing import Dict, List, Tuple, Optional

import numpy as np


# -----------------------------
# Locked thresholds (from NULLS.md)
# -----------------------------
THRESH_DELTA_PSD_DB = 6.0
THRESH_N_OVER = 2
THRESH_R_MEAN = 0.35

NULL2_MIN_AREA_FRACTION = 0.02
NULL2_MIN_LCC_SIZE = 20

NULL3_MAX_ROW_SPAN_FRACTION = 0.60

NULL4_NC_AREA_FRACTION = 0.80


# -----------------------------
# Helpers
# -----------------------------
def ensure_dir(path: str) -> None:
    os.makedirs(path, exist_ok=True)


def stable_seed(base_seed: int, K: float, gamma: float, rep: int) -> int:
    # Deterministic "hash" without Python's randomized hash() salt:
    # Use a simple integer mix.
    k_i = int(round(K * 1000))
    g_i = int(round(gamma * 1000))
    x = (base_seed ^ (k_i * 2654435761) ^ (g_i * 1597334677) ^ (rep * 3812015801)) & 0xFFFFFFFF
    return int(x)


def mad(x: np.ndarray) -> float:
    med = np.median(x)
    return float(np.median(np.abs(x - med)) + 1e-12)


def welch_psd(x: np.ndarray, fs: float, nperseg: int = 4096, noverlap: int = 2048) -> Tuple[np.ndarray, np.ndarray]:
    """
    Simple Welch PSD (numpy-only).
    Returns frequencies f and power spectral density Pxx.
    """
    x = np.asarray(x, dtype=np.float64)
    if x.ndim != 1:
        raise ValueError("welch_psd expects 1D signal")
    if len(x) < nperseg:
        nperseg = max(256, 2 ** int(math.floor(math.log2(max(256, len(x))))))
        noverlap = nperseg // 2

    step = nperseg - noverlap
    if step <= 0:
        raise ValueError("noverlap must be < nperseg")

    window = np.hanning(nperseg)
    scale = np.sum(window**2)

    segments = []
    for start in range(0, len(x) - nperseg + 1, step):
        seg = x[start:start+nperseg]
        seg = seg - np.mean(seg)
        segw = seg * window
        X = np.fft.rfft(segw)
        P = (np.abs(X) ** 2) / (fs * scale)
        segments.append(P)

    if not segments:
        # Fallback: periodogram
        x0 = x - np.mean(x)
        X = np.fft.rfft(x0)
        Pxx = (np.abs(X) ** 2) / (fs * len(x0))
        f = np.fft.rfftfreq(len(x0), d=1/fs)
        return f, Pxx

    Pxx = np.mean(np.vstack(segments), axis=0)
    f = np.fft.rfftfreq(nperseg, d=1/fs)
    return f, Pxx


def psd_peak_prominence_db(Pxx: np.ndarray) -> float:
    # Exclude DC bin (index 0)
    P = np.asarray(Pxx, dtype=np.float64)
    if P.size < 3:
        return 0.0
    P_ndc = P[1:]
    peak = float(np.max(P_ndc))
    base = float(np.median(P_ndc) + 1e-18)
    return 10.0 * math.log10((peak + 1e-18) / base)


def count_upward_crossings(x: np.ndarray, thr: float) -> int:
    above = x > thr
    return int(np.sum((~above[:-1]) & (above[1:])))


def connected_components_4(grid: np.ndarray) -> List[int]:
    """
    Returns component sizes for 4-neighbor connectivity in a boolean grid.
    """
    H, W = grid.shape
    visited = np.zeros_like(grid, dtype=bool)
    sizes = []

    for i in range(H):
        for j in range(W):
            if grid[i, j] and not visited[i, j]:
                stack = [(i, j)]
                visited[i, j] = True
                size = 0
                while stack:
                    x, y = stack.pop()
                    size += 1
                    for dx, dy in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < H and 0 <= ny < W and grid[nx, ny] and not visited[nx, ny]:
                            visited[nx, ny] = True
                            stack.append((nx, ny))
                sizes.append(size)
    return sizes


def row_span_fraction(grid_row: np.ndarray) -> float:
    """
    For a boolean row over K, compute fraction of K-range spanned by RINGING set,
    defined as (max_idx - min_idx + 1) / len(row) for non-empty sets.
    """
    idx = np.where(grid_row)[0]
    if idx.size == 0:
        return 0.0
    return float((idx.max() - idx.min() + 1) / grid_row.size)


@dataclass
class RFOParams:
    # Dynamics
    dt: float = 0.01
    steps_total: int = 200000
    steps_burnin: int = 50000
    # Network
    N: int = 128
    omega_mean: float = 1.0
    omega_std: float = 0.05
    # Drive
    D: float = 0.20
    Omega: float = 1.0
    # Plasticity
    alpha: float = 0.20
    beta: float = 0.10
    W_max: float = 1.00
    W_init_value: float = 0.20


def simulate_point(K: float, gamma: float, seed: int, params: RFOParams, save_timeseries: bool = False) -> Dict[str, object]:
    """
    Simulate a single (K,gamma,seed) run and return summary metrics + optional timeseries.
    """
    rng = np.random.default_rng(seed)

    N = params.N
    dt = params.dt
    fs = 1.0 / dt

    theta = rng.uniform(0.0, 2.0 * math.pi, size=N).astype(np.float64)
    omega = rng.normal(params.omega_mean, params.omega_std, size=N).astype(np.float64)

    W = np.full((N, N), params.W_init_value, dtype=np.float64)

    # Pre-allocate measurement arrays
    steps_measure = params.steps_total - params.steps_burnin
    r_ts = np.empty(steps_measure, dtype=np.float64)
    R_ts = np.empty(steps_measure, dtype=np.float64)

    eps = 1e-12
    measure_idx = 0

    for step in range(params.steps_total):
        t = step * dt

        # Pairwise phase differences
        diff = theta[None, :] - theta[:, None]  # (i,j): theta_j - theta_i with sign; using broadcasting
        coupling = np.sum(W * np.sin(diff), axis=1) * (K / N)

        drive = params.D * np.sin(params.Omega * t - theta)
        noise = rng.normal(0.0, gamma * math.sqrt(dt), size=N)

        theta = theta + dt * (omega + coupling + drive) + noise

        # Plasticity update
        if params.alpha != 0.0:
            W = W + dt * (params.alpha * np.cos(diff) - params.beta * W)
            W = np.clip(W, 0.0, params.W_max)

        if step >= params.steps_burnin:
            z = np.exp(1j * theta)
            r = np.abs(np.mean(z))
            m = float(np.mean(W))
            s = float(np.std(W))
            R = s / (m + eps)
            r_ts[measure_idx] = r
            R_ts[measure_idx] = R
            measure_idx += 1

    # Diagnostics
    f, Pxx = welch_psd(r_ts, fs=fs)
    delta_psd_db = psd_peak_prominence_db(Pxx)

    medR = float(np.median(R_ts))
    madR = mad(R_ts)
    ZR = (R_ts - medR) / madR
    n_over = count_upward_crossings(ZR, thr=1.0)

    r_mean = float(np.mean(r_ts))

    ring = bool((delta_psd_db >= THRESH_DELTA_PSD_DB) and (n_over >= THRESH_N_OVER) and (r_mean >= THRESH_R_MEAN))

    out: Dict[str, object] = {
        "K": float(K),
        "gamma": float(gamma),
        "seed": int(seed),
        "r_mean": r_mean,
        "Delta_PSD_dB": float(delta_psd_db),
        "N_over": int(n_over),
        "ring_label": ring,
    }

    if save_timeseries:
        out["r_ts"] = r_ts
        out["R_ts"] = R_ts
        out["psd_f"] = f
        out["psd"] = Pxx

    return out


def majority_vote(labels: List[bool]) -> bool:
    return bool(sum(1 for x in labels if x) >= (len(labels) // 2 + 1))


def evaluate_nulls(ring_grid: np.ndarray,
                   control_ring_grid: Optional[np.ndarray],
                   K_vals: np.ndarray,
                   gamma_vals: np.ndarray) -> Dict[str, object]:
    """
    Compute NULLS.md rejection conditions from ring label grids.
    Returns structured results.
    """
    H, W = ring_grid.shape
    total = H * W
    S = int(np.sum(ring_grid))
    area_frac = S / total if total else 0.0

    # Null 1 is checked during labeling; here we approximate by area_frac > 0
    null1_reject = (S == 0)

    # Null 2
    comp_sizes = connected_components_4(ring_grid)
    lcc = max(comp_sizes) if comp_sizes else 0
    null2_reject = (area_frac < NULL2_MIN_AREA_FRACTION) or (lcc < NULL2_MIN_LCC_SIZE)

    # Null 3
    row_spans = [row_span_fraction(ring_grid[i, :]) for i in range(H)]
    null3_reject = all((np.sum(ring_grid[i, :]) == 0) or (row_spans[i] > NULL3_MAX_ROW_SPAN_FRACTION) for i in range(H))

    # Null 4
    null4_reject = False
    nc_area_frac = None
    if control_ring_grid is not None:
        S_nc = int(np.sum(control_ring_grid))
        nc_area_frac = S_nc / total if total else 0.0
        null4_reject = (S_nc >= int(NULL4_NC_AREA_FRACTION * S)) if S > 0 else False

    rejected = null1_reject or null2_reject or null3_reject or null4_reject

    return {
        "rejected": bool(rejected),
        "nulls": {
            "null1_no_ringing_anywhere": {"reject": bool(null1_reject), "S": S},
            "null2_no_wedge_region": {
                "reject": bool(null2_reject),
                "area_fraction": float(area_frac),
                "lcc_size": int(lcc),
                "thresholds": {"min_area_fraction": NULL2_MIN_AREA_FRACTION, "min_lcc_size": NULL2_MIN_LCC_SIZE},
            },
            "null3_no_bounded_wedge": {
                "reject": bool(null3_reject),
                "max_row_span_fraction": float(max(row_spans) if row_spans else 0.0),
                "threshold": NULL3_MAX_ROW_SPAN_FRACTION,
            },
            "null4_negative_control_contradiction": {
                "reject": bool(null4_reject),
                "control_area_fraction": (float(nc_area_frac) if nc_area_frac is not None else None),
                "threshold_area_fraction": NULL4_NC_AREA_FRACTION,
            },
        },
        "summary": {
            "grid_shape": [int(H), int(W)],
            "S": int(S),
            "area_fraction": float(area_frac),
            "row_span_fractions": [float(x) for x in row_spans],
        },
    }


def write_wedge_report(out_path: str, eval_result: Dict[str, object]) -> None:
    lines = []
    lines.append("# wedge_report.md")
    lines.append("")
    lines.append("This report is generated by `experiment_0001_rfo_ringing_wedge.py`.")
    lines.append("It summarizes NULL evaluations and basic region diagnostics.")
    lines.append("")
    lines.append("## Null evaluation")
    lines.append("")
    lines.append(f"- **Rejected:** `{eval_result['rejected']}`")
    lines.append("")
    for k, v in eval_result["nulls"].items():
        lines.append(f"### {k}")
        lines.append("")
        lines.append(f"- reject: `{v['reject']}`")
        for kk, vv in v.items():
            if kk == "reject":
                continue
            lines.append(f"- {kk}: `{vv}`")
        lines.append("")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def parse_prereg_yaml_text(path: str) -> str:
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="outputs", help="Output directory (created).")
    ap.add_argument("--quick", action="store_true", help="Run a tiny sweep + short sim for smoke tests.")
    ap.add_argument("--no-negative-control", action="store_true", help="Skip negative control (not prereg; for debugging).")
    ap.add_argument("--save-timeseries", action="store_true", help="Save r(t)/R(t)/PSD arrays for each point (large).")
    args = ap.parse_args()

    ensure_dir(args.out)
    ensure_dir(os.path.join(args.out, "points"))

    # Load prereg text for provenance
    prereg_path = os.path.join(os.path.dirname(__file__), "..", "PREREG.yaml")
    prereg_txt = parse_prereg_yaml_text(prereg_path)

    # Resolve parameters (quick vs prereg)
    params = RFOParams()
    base_seed = 4200001

    if args.quick:
        # Smoke-test settings (do not claim prereg compliance; write deviation note)
        params.N = 32
        params.steps_total = 6000
        params.steps_burnin = 1000
        K_vals = np.linspace(1.0, 3.0, 3)
        gamma_vals = np.linspace(0.05, 0.15, 3)
        replicates = 1
    else:
        K_vals = np.linspace(0.0, 8.0, 81)
        gamma_vals = np.linspace(0.0, 0.60, 61)
        replicates = 3

    # Save parameters_used.json
    parameters_used = {
        "bundle_id": "0001_rfo_ringing_wedge",
        "version": "1.0",
        "timestamp": dt.datetime.now().isoformat(),
        "quick_mode": bool(args.quick),
        "params": asdict(params),
        "sweep": {
            "K": {"min": float(K_vals.min()), "max": float(K_vals.max()), "num": int(K_vals.size)},
            "gamma": {"min": float(gamma_vals.min()), "max": float(gamma_vals.max()), "num": int(gamma_vals.size)},
            "replicates": int(replicates),
        },
        "thresholds_locked_from_NULLS": {
            "Delta_PSD_dB": THRESH_DELTA_PSD_DB,
            "N_over": THRESH_N_OVER,
            "r_mean": THRESH_R_MEAN,
        },
        "prereg_text_sha256": None,  # can be filled by bot
        "prereg_text_included": True,
    }
    with open(os.path.join(args.out, "parameters_used.json"), "w", encoding="utf-8") as f:
        json.dump(parameters_used, f, indent=2)

    # Seed manifest
    seed_manifest = {
        "bundle_id": "0001_rfo_ringing_wedge",
        "base_seed": base_seed,
        "seed_rule": "seed = base_seed + stable_mix(K,gamma,rep)",
        "resolved": [],
    }

    # Run sweep
    ring_grid = np.zeros((gamma_vals.size, K_vals.size), dtype=bool)
    control_ring_grid = np.zeros_like(ring_grid, dtype=bool) if (not args.no_negative_control) else None

    grid_rows = []

    for gi, gamma in enumerate(gamma_vals):
        for ki, K in enumerate(K_vals):
            rep_labels = []
            rep_summaries = []
            for rep in range(replicates):
                seed = stable_seed(base_seed, float(K), float(gamma), rep)
                seed_manifest["resolved"].append({"K": float(K), "gamma": float(gamma), "rep": int(rep), "seed": int(seed)})

                summary = simulate_point(float(K), float(gamma), seed, params, save_timeseries=args.save_timeseries)
                rep_labels.append(bool(summary["ring_label"]))
                rep_summaries.append(summary)

                # Write per-replicate point summary
                point_path = os.path.join(args.out, "points", f"K{K:.3f}_g{gamma:.3f}_rep{rep}.json")
                with open(point_path, "w", encoding="utf-8") as f:
                    # Avoid writing raw arrays unless save_timeseries
                    if args.save_timeseries:
                        s2 = dict(summary)
                        # Convert arrays to lists (huge) only if requested
                        for karr in ["r_ts", "R_ts", "psd_f", "psd"]:
                            if karr in s2:
                                s2[karr] = s2[karr].tolist()
                        json.dump(s2, f)
                    else:
                        json.dump(summary, f)

            label = majority_vote(rep_labels)
            ring_grid[gi, ki] = label

            # Aggregate summary across reps (mean of metrics)
            agg = {
                "K": float(K),
                "gamma": float(gamma),
                "ring_label": bool(label),
                "r_mean": float(np.mean([s["r_mean"] for s in rep_summaries])),
                "Delta_PSD_dB": float(np.mean([s["Delta_PSD_dB"] for s in rep_summaries])),
                "N_over": float(np.mean([s["N_over"] for s in rep_summaries])),
            }
            grid_rows.append(agg)

    # Negative control (plasticity off)
    if control_ring_grid is not None:
        params_nc = RFOParams(**asdict(params))
        params_nc.alpha = 0.0

        for gi, gamma in enumerate(gamma_vals):
            for ki, K in enumerate(K_vals):
                rep_labels = []
                for rep in range(replicates):
                    seed = stable_seed(base_seed, float(K), float(gamma), rep)
                    summary = simulate_point(float(K), float(gamma), seed, params_nc, save_timeseries=False)
                    rep_labels.append(bool(summary["ring_label"]))
                control_ring_grid[gi, ki] = majority_vote(rep_labels)

    # Write seed manifest
    with open(os.path.join(args.out, "seed_manifest.json"), "w", encoding="utf-8") as f:
        json.dump(seed_manifest, f, indent=2)

    # Write grid.csv
    grid_csv = os.path.join(args.out, "grid.csv")
    import csv
    with open(grid_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["K", "gamma", "ring_label", "r_mean", "Delta_PSD_dB", "N_over"])
        w.writeheader()
        for row in grid_rows:
            w.writerow(row)

    # Evaluate NULLS and write reports
    eval_res = evaluate_nulls(ring_grid, control_ring_grid, K_vals, gamma_vals)
    with open(os.path.join(args.out, "null_evaluation.json"), "w", encoding="utf-8") as f:
        json.dump(eval_res, f, indent=2)

    write_wedge_report(os.path.join(args.out, "wedge_report.md"), eval_res)

    # Write a brief deviations note if quick mode
    if args.quick:
        with open(os.path.join(args.out, "DEVIATIONS_FROM_PREREG.md"), "w", encoding="utf-8") as f:
            f.write("# Deviations from PREREG\n\n")
            f.write("This run used `--quick` smoke-test parameters (smaller N, shorter steps, smaller grid, fewer reps).\n")
            f.write("Do not treat results as prereg-compliant.\n")

    print(f"[bundle 0001] wrote outputs to: {args.out}")
    print(f"[bundle 0001] rejected: {eval_res['rejected']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
