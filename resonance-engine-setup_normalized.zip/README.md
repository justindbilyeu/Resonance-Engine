# Resonance Engine Setup Kit (Normalized)

This package is intended to be committed into the **Resonance-Engine** repository.

## Contents
- `docs/setup/` — setup guides + Claude Code instructions
- `scripts/organize_repos.py` — automation script to integrate the four repos into the target structure
- `bundles/0001_rfo_ringing_wedge/` — Bundle #0001 (golden path) including runnable scaffold + tests

## Note
Docs include placeholder GitHub URLs like `YourUsername`. Replace with `justindbilyeu` (or your org) before use.
